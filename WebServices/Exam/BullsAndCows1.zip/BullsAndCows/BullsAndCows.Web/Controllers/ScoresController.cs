﻿namespace BullsAndCows.Web.Controllers
{
    using BullsAndCows.Data;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;

    public class ScoresController : BaseApiController
    {
        public ScoresController(IGameData data) 
            : base(data)
        {
        }

        [HttpGet]
        public IHttpActionResult All()
        {
            //var result = this.data.UserDetails.All()

            return Ok();
        }
    }
}
