namespace BullsAndCows.Models
{
    using System;
    using System.Linq;

    public enum NotificationType
    {
        YourTurn,
        GameWon,
        GameLost,
        GameJoined
    }
}
