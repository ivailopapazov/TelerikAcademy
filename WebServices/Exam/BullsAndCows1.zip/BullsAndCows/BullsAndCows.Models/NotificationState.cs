namespace BullsAndCows.Models
{
    using System;
    using System.Linq;

    public enum NotificationState
    {
        Read,
        Unread
    }
}
