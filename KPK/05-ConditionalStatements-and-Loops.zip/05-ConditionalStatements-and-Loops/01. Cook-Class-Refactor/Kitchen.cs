﻿using System;

namespace CheffClassRefactor
{
    class Kitchen
    {
        static void Main(string[] args)
        {
        }
    }
}
